const db = require('../db');

const line_signup = (req, res) => {
  const { User_ID, Display_Name, Age, Gender, Occupation, Usually_Bus_Use } = req.body;
  const user = { User_ID, Display_Name, Age, Gender, Occupation, Usually_Bus_Use };

  // Check if User_ID already exists in the database
  const checkUserExistsQuery = 'SELECT COUNT(*) AS count FROM line_basic_information WHERE User_ID = ?';
  db.query(checkUserExistsQuery, User_ID, (checkErr, checkResult) => {
    if (checkErr) {
      throw checkErr;
    }

    const userCount = checkResult[0].count;
    if (userCount > 0) {
      // User_ID already exists, handle accordingly (e.g., redirect to another page)
      res.render('pages/Boarding_Insert', { User_ID });
    } else {
      // User_ID doesn't exist, proceed to insert
      const insertQuery = 'INSERT INTO line_basic_information SET ?';
      db.query(insertQuery, user, (insertErr, insertResult) => {
        if (insertErr) {
          throw insertErr;
        }
        console.log('User inserted:', insertResult);
        res.render('pages/Boarding_Insert', { User_ID });
      });
    }
  });
};


const line_check_user= (req, res) => {
  const user_id = req.query.user_id;
  const user_name = req.query.user_name;

  const checkUserExistsQuery = 'SELECT COUNT(*) AS count FROM line_basic_information WHERE User_ID = ?';
  db.query(checkUserExistsQuery, [user_id], (checkErr, checkResult) => {
    if (checkErr) {
      throw checkErr;
    }

    const userCount = checkResult[0].count;
    if (userCount > 0) {
      // User_ID already exists, render Boarding_Insert page
      res.render('pages/Boarding_Insert', { User_ID: user_id, name: user_name });
    } else {
      // User_ID doesn't exist, render index for signup
      res.render('pages/index', { id: user_id, name: user_name });
    }
  });
};





module.exports={
    line_signup,
    line_check_user,
};