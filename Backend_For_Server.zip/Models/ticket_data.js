const db=require('../db')
const bording_info_insert=function (req, res) {
    console.log('Form data received:', req.body);
      var Getoff_Bus_Stop = req.body.Getoff_Bus_Stop;
      var Boarding_Bus_Stop = req.body.Boarding_Bus_Stop;
      var adults = req.body.adults;
      var child = req.body.child;
      var Purpose = req.body.Purpose;
      var User_ID=req.body.User_ID;
      var sql = "INSERT INTO ticket_and_user (User_ID,Getoff, Bording, Adults, Childs, Purpose, TimeStamp) VALUES (?,?, ?, ?, ?, ?, NOW())";

      db.query(sql, [User_ID,Getoff_Bus_Stop, Boarding_Bus_Stop, adults, child, Purpose], function (err, result) {
          if (err) {
              console.error(err);
              return res.status(500).send('Error inserting data into the database');
          }

          console.log('Record inserted');
          res.send('Data added successfully!');
      });
  };

  const bording_info_display = (req, res) => {
    const page = parseInt(req.query.page) || 1;  // Current page number, default is 1
    const limit = 6;  // Number of items per page
  
    const offset = (page - 1) * limit;
  
    const query = 'SELECT * FROM ticket_and_user LIMIT ?, ?';
    db.query(query, [offset, limit], (err, rows) => {
      if (err) {
        console.error('Error executing query: ' + err.message);
        return res.status(500).send('Error retrieving data from the database');
      }
  
      res.render('pages/data', { data: rows, currentPage: page });
    });
  };
  module.exports={
    bording_info_insert,
    bording_info_display,
  };