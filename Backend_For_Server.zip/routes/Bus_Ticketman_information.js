const express = require('express');
const router = express.Router();

const {
  bording_info_insert,
  bording_info_display,
}=require('../Models/ticket_data');
router.post('/ticket_insert',bording_info_insert);
router.get('/data', (req, res) => {
  const page = parseInt(req.query.page) || 1;  // Current page number, default is 1

  // Call the bording_info_display function passing the page parameter
  bording_info_display(req, res, page);
});

router.get('/boarding', (req, res) => {
  res.render('pages/boarding_insert');
});


router.get("/driver_login", (req, res) => {
  res.render("pages/driver_login");
});

router.get("/",(req,res)=>{
  res.send('Hello, Welcome to home Page');

});

module.exports = router;
