const express = require('express');
const router = express.Router();

//Create Different Login API
const {
    line_login_redirect,
    line_login_direct_outside,
  }=require('../Components/line_function');
const {
    line_signup,
    line_check_user,
  }=require('../Models/line_data');



  router.get('/line2',line_login_redirect );

  router.get("/line_home", (req, res) => {
    res.render("pages/index")
  });
  
  router.post('/signup', line_signup);

  router.get('/line', (req, res) => {
    res.render('pages/line_test');
  });
  
  router.get('/line3', (req, res) => {
    res.render('pages/login_with_line');
  });

  router.get("/Line_Check", line_check_user);
  router.get("/line4", line_login_direct_outside);


module.exports=router;



